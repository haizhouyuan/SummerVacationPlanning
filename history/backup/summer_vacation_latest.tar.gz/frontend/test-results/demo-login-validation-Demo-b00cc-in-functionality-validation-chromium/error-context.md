# Page snapshot

```yaml
- text: 🏖️
- heading "欢迎回来！" [level=2]
- paragraph: 登录您的暑假计划账户
- text: 🔧
- strong: 网络兼容模式已启用
- text: 适配受限网络环境，正常登录使用 邮箱地址
- textbox "邮箱地址"
- text: 密码
- textbox "密码"
- button "登录"
- text: 还没有账户？
- link "立即注册":
  - /url: /register
- paragraph: 快速体验演示账号
- button "👨‍🎓 学生演示"
- button "👨‍👩‍👧‍👦 家长演示"
- iframe
```