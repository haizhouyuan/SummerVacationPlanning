Redirecting to https://classic.yarnpkg.com/downloads/1.22.22/yarn-1.22.22.js
